﻿using CODEFIRST.CRUD.Interface;
using Microsoft.AspNetCore.Mvc;

namespace CODEFIRST.CRUD.Controllers
{
    public class CategoryController : Controller
    {
        #region Index
        public IActionResult Index()
        {
            return View();
        }
        #endregion
    }
}