﻿using CODEFIRST.CRUD.Models;

namespace CODEFIRST.CRUD.Interface
{
    public interface ICategoryRep
    {
        //GetAll
        Task<IEnumerable<Category>> GetAll();

        //Add
        Task Add(Category category);

        //GetById
        Task<Category> GetById(int id);

        //Update
        Task Update(Category category);

        //Delete
        Task Delete(int id);
    }
}
