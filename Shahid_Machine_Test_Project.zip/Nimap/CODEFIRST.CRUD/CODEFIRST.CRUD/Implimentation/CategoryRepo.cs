﻿using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace CODEFIRST.CRUD.Implimentation
{
    public class CategoryRepo : ICategoryRep
    {
        #region private field for db access
        private readonly MyAppDbContext _context;
        #endregion

        #region constructor for accessing the field and inilizing
        public CategoryRepo(MyAppDbContext context)
        {
            _context = context;
        }
        #endregion

        #region GetAll
        public async Task<IEnumerable<Category>> GetAll()
        {
            var category = await _context.Categories.ToListAsync();
            return category;
        }
        #endregion

        #region Add
        public async Task Add(Category category)
        {
            await _context.Categories.AddAsync(category);
            await Save();

        }
        #endregion

        #region GetById
        public async Task<Category> GetById(int id)
        {
            return await _context.Categories.FindAsync(id);
        }
        #endregion

        #region Update
        public async Task Update(Category model)
        {
            var category = await _context.Categories.FindAsync(model.CategoryId);
            if (category != null)
            {
                category.CategoryName = model.CategoryName;
                _context.Update(category);
                await Save();
            }
        }
        #endregion

        #region Delete
        public async Task Delete(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
                await Save();
            }
        }
        #endregion

        #region Private SaveChanges Method
        private async Task Save()
        {
            await _context.SaveChangesAsync();
        }
        #endregion
    }
}
